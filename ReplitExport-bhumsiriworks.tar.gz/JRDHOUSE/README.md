# JRDHOUSE Coffee Shop Management System

A real-time coffee shop ordering and management system built with React and Firebase.

## Features

### Customer Interface
- Browse menu with customizable options (beans, milk, flavor, sweetness, temperature)
- Add items to cart with real-time price calculation
- Select pickup time slots
- QR code payment integration (PromptPay placeholder)
- Real-time order status tracking
- Ice separation option for iced drinks

### Staff Dashboard
- Live order queue with real-time updates
- Payment confirmation workflow
- Order status management (Pending → Preparing → Ready → Completed)
- Menu editor with customization options
- Visual status indicators and time tracking

## Tech Stack

- **Frontend**: React 18 with Vite
- **Styling**: Tailwind CSS (via CDN)
- **Backend**: Firebase Firestore (real-time database)
- **Authentication**: Firebase Anonymous Auth

## Setup Instructions

### 1. Install Dependencies

```bash
npm install
```

### 2. Configure Firebase

1. Create a Firebase project at [console.firebase.google.com](https://console.firebase.google.com)
2. Enable Firestore Database in your Firebase project
3. Enable Anonymous Authentication in Firebase Authentication settings
4. Copy your Firebase configuration

### 3. Environment Variables

Create a `.env` file in the root directory (use `.env.example` as a template):

```bash
VITE_FIREBASE_API_KEY=your-api-key-here
VITE_FIREBASE_AUTH_DOMAIN=your-project.firebaseapp.com
VITE_FIREBASE_PROJECT_ID=your-project-id
VITE_FIREBASE_STORAGE_BUCKET=your-project.appspot.com
VITE_FIREBASE_MESSAGING_SENDER_ID=123456789
VITE_FIREBASE_APP_ID=1:123456789:web:abcdef
VITE_APP_ID=jrdhouse
```

### 4. Firestore Security Rules

Set up the following Firestore security rules in your Firebase console:

```javascript
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /artifacts/{appId}/public/data/{document=**} {
      allow read, write: if request.auth != null;
    }
  }
}
```

### 5. Run the Development Server

```bash
npm run dev
```

The app will be available at `http://localhost:5000`

## Usage

### Accessing the App

When you first open the app, you'll see two options:
- **Customer Order**: For customers to browse menu and place orders
- **Staff Dashboard**: For staff to manage orders and menu

### Customer Flow

1. Enter your name
2. Browse the menu
3. Customize items and add to cart
4. Select pickup time
5. Complete payment via QR code
6. Track order status in real-time

### Staff Flow

1. View incoming orders in real-time
2. Approve payment confirmations
3. Update order status as preparation progresses
4. Edit menu items and options in the Menu tab

## Project Structure

```
├── src/
│   ├── components/
│   │   ├── Admin.js       # Staff dashboard
│   │   └── Customer.js    # Customer ordering interface
│   ├── App.jsx            # Main app with mode selector
│   ├── main.jsx           # React entry point
│   └── firebase-config.js # Firebase configuration
├── index.html             # HTML template
├── vite.config.js         # Vite configuration
└── package.json           # Dependencies
```

## Firebase Data Structure

### Collections

- `artifacts/{appId}/public/data/menu` - Menu items
- `artifacts/{appId}/public/data/orders` - Customer orders

### Menu Item Schema

```javascript
{
  id: "espresso",
  name: "Espresso",
  category: "Espresso Drinks",
  price: 3.00,
  options: {
    beans: ["Dark", "Medium-Dark", "Medium", "Light"],
    sweetness: ["100", "50", "25"],
    temperature: ["Hot", "Iced"]
  }
}
```

### Order Schema

```javascript
{
  userId: "auth-user-id",
  customerName: "John Doe",
  orderItems: [...],
  pickupTime: "2:30 PM",
  paymentStatus: "Waiting for Confirmation" | "Confirmed",
  paymentAmount: 15.60,
  status: "Waiting for Payment Confirmation" | "Pending" | "Preparing" | "Ready" | "Completed",
  createdAt: Timestamp
}
```

## Deployment

To deploy this app, you'll need to:

1. Build the production version:
```bash
npm run build
```

2. Deploy the `dist` folder to your hosting service
3. Ensure Firebase credentials are set via environment variables in your production environment

## Notes

- The QR code payment integration uses a placeholder. For production, integrate with a real payment provider API.
- The app uses Firebase Anonymous Authentication by default. Consider implementing proper user authentication for production.
- Initial menu items are automatically created when the database is empty (see `Customer.js`).

## License

This project is for demonstration purposes.
