import React, { useState } from 'react';
import AdminApp from './components/Admin.jsx';
import CustomerApp from './components/Customer.jsx';
import { initError } from './firebase-config';

function App() {
  const [mode, setMode] = useState(null);
  const [isAdminAuthenticated, setIsAdminAuthenticated] = useState(false);
  const [passwordInput, setPasswordInput] = useState('');
  const [passwordError, setPasswordError] = useState(false);

  const handleAdminLogin = (e) => {
    e.preventDefault();
    if (passwordInput === '134679') {
      setIsAdminAuthenticated(true);
      setPasswordError(false);
      setPasswordInput('');
    } else {
      setPasswordError(true);
      setPasswordInput('');
    }
  };

  if (initError) {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen bg-red-50 p-4">
        <div className="bg-white rounded-2xl shadow-2xl p-8 max-w-md w-full text-center border-t-4 border-red-600">
          <div className="text-red-600 mb-4">
            <svg className="w-16 h-16 mx-auto" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
            </svg>
          </div>
          <h1 className="text-2xl font-bold text-gray-800 mb-3">
            Firebase Configuration Required
          </h1>
          <p className="text-gray-600 mb-4">
            {initError}
          </p>
          <div className="bg-gray-50 rounded-lg p-4 text-left text-sm">
            <p className="font-semibold text-gray-700 mb-2">To set up Firebase:</p>
            <ol className="list-decimal list-inside space-y-1 text-gray-600">
              <li>Create a Firebase project at console.firebase.google.com</li>
              <li>Enable Firestore Database</li>
              <li>Copy your Firebase config to a .env file</li>
              <li>See .env.example for required variables</li>
            </ol>
          </div>
        </div>
      </div>
    );
  }

  if (!mode) {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen bg-gradient-to-br from-red-50 to-orange-50 p-4">
        <div className="bg-white rounded-2xl shadow-2xl p-8 max-w-md w-full text-center border-t-4 border-red-600">
          <h1 className="text-4xl font-black text-red-700 mb-3">
            JRDHOUSE
          </h1>
          <p className="text-gray-600 mb-8 text-lg">Coffee Shop Management System</p>
          
          <div className="space-y-4">
            <button
              onClick={() => setMode('customer')}
              className="w-full bg-red-600 hover:bg-red-700 text-white font-extrabold py-4 px-6 rounded-xl transition duration-200 shadow-xl text-lg"
            >
              Customer Order
            </button>
            
            <button
              onClick={() => setMode('admin')}
              className="w-full bg-gray-800 hover:bg-gray-900 text-white font-extrabold py-4 px-6 rounded-xl transition duration-200 shadow-xl text-lg"
            >
              Staff Dashboard
            </button>
          </div>
          
          <p className="text-xs text-gray-400 mt-6">Select your interface to continue</p>
        </div>
      </div>
    );
  }

  if (mode === 'admin') {
    if (!isAdminAuthenticated) {
      return (
        <div className="flex flex-col items-center justify-center min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 p-4">
          <div className="bg-white rounded-2xl shadow-2xl p-8 max-w-md w-full border-t-4 border-gray-800">
            <h2 className="text-3xl font-bold text-gray-800 mb-2 text-center">Staff Dashboard</h2>
            <p className="text-gray-600 mb-6 text-center">Enter password to continue</p>
            
            <form onSubmit={handleAdminLogin} className="space-y-4">
              <div>
                <input
                  type="password"
                  value={passwordInput}
                  onChange={(e) => setPasswordInput(e.target.value)}
                  placeholder="Enter password"
                  className={`w-full px-4 py-3 border-2 ${passwordError ? 'border-red-500' : 'border-gray-300'} rounded-lg focus:outline-none focus:border-gray-800 transition duration-200`}
                  autoFocus
                />
                {passwordError && (
                  <p className="text-red-500 text-sm mt-2">Incorrect password. Please try again.</p>
                )}
              </div>
              
              <button
                type="submit"
                className="w-full bg-gray-800 hover:bg-gray-900 text-white font-bold py-3 px-6 rounded-lg transition duration-200 shadow-lg"
              >
                Login
              </button>
              
              <button
                type="button"
                onClick={() => {
                  setMode(null);
                  setPasswordError(false);
                  setPasswordInput('');
                }}
                className="w-full text-sm text-gray-500 hover:text-gray-700 mt-2"
              >
                ← Back to Menu
              </button>
            </form>
          </div>
        </div>
      );
    }
    
    return (
      <div>
        <button
          onClick={() => {
            setMode(null);
            setIsAdminAuthenticated(false);
          }}
          className="fixed top-4 left-4 bg-gray-800 hover:bg-gray-900 text-white font-semibold py-2 px-4 rounded-lg shadow-lg z-50 text-sm"
        >
          ← Back to Menu
        </button>
        <AdminApp />
      </div>
    );
  }

  return (
    <div>
      <button
        onClick={() => setMode(null)}
        className="fixed top-4 left-4 bg-gray-800 hover:bg-gray-900 text-white font-semibold py-2 px-4 rounded-lg shadow-lg z-50 text-sm"
      >
        ← Back to Menu
      </button>
      <CustomerApp />
    </div>
  );
}

export default App;
