import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';

const appId = typeof window !== 'undefined' && typeof window.__app_id !== 'undefined' 
  ? window.__app_id 
  : import.meta.env.VITE_APP_ID || 'jrdhouse-demo';

const firebaseConfig = typeof window !== 'undefined' && typeof window.__firebase_config !== 'undefined' 
  ? JSON.parse(window.__firebase_config) 
  : {
      apiKey: import.meta.env.VITE_FIREBASE_API_KEY,
      authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN,
      projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID,
      storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET,
      messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID,
      appId: import.meta.env.VITE_FIREBASE_APP_ID
    };

const initialAuthToken = typeof window !== 'undefined' && typeof window.__initial_auth_token !== 'undefined' 
  ? window.__initial_auth_token 
  : null;

let app, db, auth, initError = null;

try {
  if (!firebaseConfig.apiKey) {
    throw new Error("Firebase configuration is missing. Please set up your Firebase credentials.");
  }
  app = initializeApp(firebaseConfig);
  db = getFirestore(app);
  auth = getAuth(app);
} catch (error) {
  console.error("Firebase initialization failed:", error);
  initError = error.message;
}

export { app, db, auth, appId, initialAuthToken, firebaseConfig, initError };
