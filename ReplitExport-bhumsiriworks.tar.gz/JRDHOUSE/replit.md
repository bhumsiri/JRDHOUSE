# JRDHOUSE Coffee Shop - Replit Project

## Overview
A real-time coffee shop ordering and management system with separate Customer and Staff interfaces. Built with React + Vite + Firebase Firestore.

## Project Status
- **Imported from**: GitHub
- **Setup Date**: November 11, 2025
- **Current State**: ✅ Fully configured and running with Firebase
- **Firebase**: Connected and authenticated

## Recent Changes (November 12, 2025)
- **Customer Interface**: Added quantity selector for ordering multiple items at once
- **Staff Dashboard**: Improved category management with dedicated UI for creating new categories
- **Staff Dashboard**: Fixed order visibility issue by removing Firestore index requirements
- Previously: Created Vite + React project structure from standalone components
- Previously: Centralized Firebase initialization in `src/firebase-config.js`
- Previously: Added environment variable support for Firebase configuration

## Architecture

### Frontend Structure
```
src/
├── App.jsx               # Main app with mode selector & error handling
├── main.jsx              # React entry point
├── firebase-config.js    # Centralized Firebase initialization
└── components/
    ├── Admin.js          # Staff dashboard (orders + menu management)
    └── Customer.js       # Customer interface (ordering + tracking)
```

### Key Dependencies
- React 18.2.0
- Firebase 10.7.1
- Vite 5.0.8
- Tailwind CSS (CDN)

### Firebase Collections
- `artifacts/{appId}/public/data/menu` - Menu items with customization options
- `artifacts/{appId}/public/data/orders` - Real-time order queue

## Configuration

### Required Environment Variables
Copy `.env.example` to `.env` and fill in Firebase credentials:
```
VITE_FIREBASE_API_KEY=
VITE_FIREBASE_AUTH_DOMAIN=
VITE_FIREBASE_PROJECT_ID=
VITE_FIREBASE_STORAGE_BUCKET=
VITE_FIREBASE_MESSAGING_SENDER_ID=
VITE_FIREBASE_APP_ID=
VITE_APP_ID=jrdhouse
```

### Workflow Setup
- **Frontend**: `npm run dev` on port 5000 (webview)
- Configured with `--host 0.0.0.0` for Replit proxy compatibility

## Firebase Setup Instructions

1. Create Firebase project at console.firebase.google.com
2. Enable Firestore Database
3. Enable Anonymous Authentication
4. Set security rules:
```javascript
match /artifacts/{appId}/public/data/{document=**} {
  allow read, write: if request.auth != null;
}
```
5. Copy config to `.env` file

## User Preferences
- None specified yet

## Completed Setup
- ✅ Firebase credentials configured via Replit Secrets
- ✅ Frontend workflow running on port 5000
- ✅ Deployment configuration set up for production
- ✅ App fully functional with real-time Firebase connection

## Future Enhancements
- [ ] QR payment integration is a placeholder (needs real payment API for production)
- [ ] Consider adding Firebase emulator for local dev/testing
- [ ] Set up Firestore security rules for production
- [ ] Add proper Tailwind CSS build (currently using CDN)

## Notes
- The app gracefully handles missing Firebase config with user-friendly error message
- Initial menu data is seeded automatically when database is empty
- Both Customer and Admin modes use Firebase Anonymous Auth
- Real-time updates via Firestore snapshots
