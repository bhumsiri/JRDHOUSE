import { useEffect, useState } from "react";
import { useLocation } from "wouter";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useQuery } from "@tanstack/react-query";
import { Clock, Loader2 } from "lucide-react";
import type { Order } from "@shared/schema";

export default function WaitingConfirmation() {
  const [, setLocation] = useLocation();
  const [orderId, setOrderId] = useState<string | null>(null);
  const [orderNumber, setOrderNumber] = useState<number | null>(null);

  useEffect(() => {
    const storedOrderId = sessionStorage.getItem("pendingOrderId");
    const storedOrderNumber = sessionStorage.getItem("pendingOrderNumber");
    
    if (!storedOrderId || !storedOrderNumber) {
      setLocation("/");
      return;
    }

    setOrderId(storedOrderId);
    setOrderNumber(parseInt(storedOrderNumber));
  }, [setLocation]);

  const { data: order } = useQuery<Order>({
    queryKey: ["/api/customer/orders", orderId],
    enabled: !!orderId,
    refetchInterval: 2000,
  });

  useEffect(() => {
    if (order?.paymentStatus === "confirmed") {
      sessionStorage.removeItem("pendingOrderId");
      sessionStorage.removeItem("pendingOrderNumber");
      sessionStorage.removeItem("pendingOrderTotal");
      sessionStorage.setItem("trackingOrderId", orderId!);
      setLocation("/order-tracking");
    }
  }, [order, orderId, setLocation]);

  if (!orderId || !orderNumber) {
    return null;
  }

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-background">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center space-y-4">
          <div className="flex justify-center">
            <div className="w-20 h-20 rounded-full bg-primary/10 flex items-center justify-center">
              <div className="relative">
                <Clock className="w-12 h-12 text-primary" />
                <Loader2 className="w-6 h-6 text-primary animate-spin absolute -bottom-1 -right-1" />
              </div>
            </div>
          </div>
          <div className="space-y-2">
            <CardTitle className="text-2xl">Waiting for Confirmation</CardTitle>
            <CardDescription className="text-base">
              Order #{orderNumber}
            </CardDescription>
          </div>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="text-center space-y-4">
            <div className="bg-muted/50 rounded-lg p-6 space-y-3">
              <div className="flex items-center justify-center gap-2">
                <div className="w-2 h-2 rounded-full bg-primary animate-pulse" />
                <p className="text-sm font-medium">
                  Payment Received
                </p>
              </div>
              <p className="text-sm text-muted-foreground">
                Our staff is verifying your payment
              </p>
            </div>
            
            <div className="bg-muted/30 rounded-lg p-4 space-y-2">
              <p className="text-xs text-muted-foreground">
                This usually takes 1-2 minutes
              </p>
              <p className="text-xs text-muted-foreground">
                You'll be redirected automatically when confirmed
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
