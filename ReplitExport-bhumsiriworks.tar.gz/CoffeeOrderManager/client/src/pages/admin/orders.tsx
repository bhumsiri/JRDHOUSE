import { useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Clock, User, Package, CheckCircle2, CreditCard } from "lucide-react";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { Order, Option } from "@shared/schema";
import { format } from "date-fns";

export default function AdminOrders() {
  const { toast } = useToast();
  const { data: orders, isLoading } = useQuery<Order[]>({
    queryKey: ["/api/orders"],
  });

  useEffect(() => {
    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    const wsUrl = `${protocol}//${window.location.host}/ws`;
    const socket = new WebSocket(wsUrl);

    socket.onopen = () => {
      console.log('WebSocket connected to admin orders');
    };

    socket.onmessage = (event) => {
      const data = JSON.parse(event.data);
      if (data.type === 'NEW_ORDER') {
        queryClient.invalidateQueries({ queryKey: ["/api/orders"] });
        toast({
          title: "New Order Received!",
          description: `Order #${data.order.orderNumber} from ${data.order.customerName}`,
        });
      }
    };

    socket.onerror = (error) => {
      console.error('WebSocket error:', error);
    };

    socket.onclose = () => {
      console.log('WebSocket disconnected');
    };

    return () => {
      socket.close();
    };
  }, [toast]);

  const { data: options } = useQuery<Option[]>({
    queryKey: ["/api/options"],
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case "new":
        return "default";
      case "preparing":
        return "secondary";
      case "ready":
        return "default";
      case "completed":
        return "secondary";
      default:
        return "secondary";
    }
  };

  const getStatusLabel = (status: string) => {
    switch (status) {
      case "new":
        return "New";
      case "preparing":
        return "Preparing";
      case "ready":
        return "Ready";
      case "completed":
        return "Completed";
      default:
        return status;
    }
  };

  const getPaymentStatusColor = (status: string) => {
    return status === "confirmed" ? "default" : "secondary";
  };

  const getPaymentStatusLabel = (status: string) => {
    return status === "confirmed" ? "Paid" : "Pending Payment";
  };

  const confirmPaymentMutation = useMutation({
    mutationFn: async (orderId: string) => {
      const res = await apiRequest("POST", `/api/orders/${orderId}/confirm-payment`, {});
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/orders"] });
      toast({
        title: "Payment Confirmed",
        description: "Order payment has been confirmed successfully.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to confirm payment. Please try again.",
        variant: "destructive",
      });
    },
  });

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold">Orders</h1>
          <p className="text-muted-foreground mt-2">Manage incoming customer orders</p>
        </div>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {Array.from({ length: 4 }).map((_, i) => (
            <Card key={i}>
              <CardHeader>
                <Skeleton className="h-6 w-32" />
                <Skeleton className="h-4 w-48" />
              </CardHeader>
              <CardContent>
                <Skeleton className="h-20 w-full" />
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  const sortedOrders = [...(orders || [])].sort((a, b) => 
    new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
  );

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Orders</h1>
        <p className="text-muted-foreground mt-2">Manage incoming customer orders</p>
      </div>

      {sortedOrders.length === 0 ? (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-16 text-center">
            <Package className="w-16 h-16 text-muted-foreground mb-4" />
            <h3 className="text-xl font-semibold mb-2">No orders yet</h3>
            <p className="text-muted-foreground">
              New orders will appear here as customers place them
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {sortedOrders.map((order) => {
            const items = JSON.parse(JSON.stringify(order.items));
            
            return (
              <Card key={order.id} data-testid={`order-${order.id}`}>
                <CardHeader className="pb-4">
                  <div className="flex items-start justify-between gap-4">
                    <div className="space-y-1">
                      <CardTitle className="text-xl flex items-center gap-2 flex-wrap">
                        Order #{order.orderNumber}
                        <Badge variant={getStatusColor(order.status)}>
                          {getStatusLabel(order.status)}
                        </Badge>
                        <Badge 
                          variant={getPaymentStatusColor(order.paymentStatus || "pending")}
                          data-testid={`badge-payment-${order.id}`}
                        >
                          <CreditCard className="w-3 h-3 mr-1" />
                          {getPaymentStatusLabel(order.paymentStatus || "pending")}
                        </Badge>
                      </CardTitle>
                      <CardDescription className="flex flex-col gap-1">
                        <span className="flex items-center gap-1">
                          <User className="w-3 h-3" />
                          {order.customerName}
                        </span>
                        <span className="flex items-center gap-1">
                          <Clock className="w-3 h-3" />
                          {format(new Date(order.createdAt), "MMM d, yyyy 'at' h:mm a")}
                        </span>
                        {order.paymentConfirmedAt && (
                          <span className="flex items-center gap-1 text-primary">
                            <CheckCircle2 className="w-3 h-3" />
                            Paid: {format(new Date(order.paymentConfirmedAt), "MMM d, h:mm a")}
                          </span>
                        )}
                      </CardDescription>
                    </div>
                    <Badge variant="secondary" className="text-lg px-3 py-1">
                      ฿{parseFloat(order.total).toFixed(2)}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <ScrollArea className="max-h-64">
                    <div className="space-y-3">
                      {items.map((item: any, idx: number) => {
                        const selectedOptions = Object.entries(item.selectedOptions || {})
                          .filter(([, value]) => value && (Array.isArray(value) ? value.length > 0 : true))
                          .map(([key, value]) => ({
                            key,
                            value: Array.isArray(value) ? value : [value],
                          }));

                        return (
                          <div key={idx} className="border-l-2 border-primary pl-3 space-y-1">
                            <div className="flex items-start justify-between gap-2">
                              <p className="font-medium">
                                {item.quantity}x {item.name}
                              </p>
                            </div>
                            {selectedOptions.length > 0 && (
                              <div className="space-y-0.5">
                                {selectedOptions.map(({ key, value }) => (
                                  <p key={key} className="text-sm text-muted-foreground">
                                    {key === "milkType" && `Milk: ${value.join(", ")}`}
                                    {key === "sweetness" && `Sweetness: ${value.join(", ")}`}
                                    {key === "addons" && `Add-ons: ${value.join(", ")}`}
                                    {key === "extras" && `Extras: ${value.join(", ")}`}
                                  </p>
                                ))}
                              </div>
                            )}
                            {item.notes && (
                              <p className="text-sm bg-muted px-2 py-1 rounded italic">
                                Note: {item.notes}
                              </p>
                            )}
                          </div>
                        );
                      })}
                    </div>
                  </ScrollArea>
                </CardContent>
                {order.paymentStatus === "pending" && (
                  <CardFooter className="pt-4 border-t">
                    <Button
                      className="w-full"
                      onClick={() => confirmPaymentMutation.mutate(order.id)}
                      disabled={confirmPaymentMutation.isPending}
                      data-testid={`button-confirm-payment-${order.id}`}
                    >
                      <CheckCircle2 className="w-4 h-4 mr-2" />
                      {confirmPaymentMutation.isPending ? "Confirming..." : "Confirm Payment Received"}
                    </Button>
                  </CardFooter>
                )}
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
}
