import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Plus, Pencil, Trash2, Settings } from "lucide-react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { insertOptionSchema, type Option } from "@shared/schema";
import { z } from "zod";

const optionFormSchema = insertOptionSchema.extend({
  price: z.string(),
});

type OptionFormValues = z.infer<typeof optionFormSchema>;

export default function AdminOptions() {
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingOption, setEditingOption] = useState<Option | null>(null);
  const [currentType, setCurrentType] = useState<string>("milk");
  const { toast } = useToast();

  const { data: options, isLoading } = useQuery<Option[]>({
    queryKey: ["/api/options"],
  });

  const form = useForm<OptionFormValues>({
    resolver: zodResolver(optionFormSchema),
    defaultValues: {
      type: "milk",
      name: "",
      price: "0",
    },
  });

  const createMutation = useMutation({
    mutationFn: async (data: OptionFormValues) => {
      return await apiRequest("POST", "/api/options", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/options"] });
      toast({ title: "Option created successfully" });
      setDialogOpen(false);
      form.reset();
    },
  });

  const updateMutation = useMutation({
    mutationFn: async ({ id, data }: { id: string; data: OptionFormValues }) => {
      return await apiRequest("PATCH", `/api/options/${id}`, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/options"] });
      toast({ title: "Option updated successfully" });
      setDialogOpen(false);
      setEditingOption(null);
      form.reset();
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      return await apiRequest("DELETE", `/api/options/${id}`, undefined);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/options"] });
      toast({ title: "Option deleted successfully" });
    },
  });

  const handleEdit = (option: Option) => {
    setEditingOption(option);
    form.reset({
      type: option.type,
      name: option.name,
      price: option.price,
    });
    setDialogOpen(true);
  };

  const handleAdd = (type: string) => {
    setCurrentType(type);
    setEditingOption(null);
    form.reset({
      type,
      name: "",
      price: "0",
    });
    setDialogOpen(true);
  };

  const onSubmit = (data: OptionFormValues) => {
    if (editingOption) {
      updateMutation.mutate({ id: editingOption.id, data });
    } else {
      createMutation.mutate(data);
    }
  };

  const getOptionsByType = (type: string) => {
    return options?.filter(o => o.type === type) || [];
  };

  const renderOptionsList = (type: string, typeName: string) => {
    const typeOptions = getOptionsByType(type);

    return (
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-semibold">{typeName}</h3>
          <Button onClick={() => handleAdd(type)} size="sm" data-testid={`button-add-${type}`}>
            <Plus className="w-4 h-4 mr-2" />
            Add {typeName}
          </Button>
        </div>

        {typeOptions.length === 0 ? (
          <Card>
            <CardContent className="flex flex-col items-center justify-center py-12 text-center">
              <Settings className="w-12 h-12 text-muted-foreground mb-3" />
              <p className="text-muted-foreground">
                No {typeName.toLowerCase()} options yet
              </p>
            </CardContent>
          </Card>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {typeOptions.map((option) => (
              <Card key={option.id} data-testid={`option-${option.id}`}>
                <CardContent className="p-4">
                  <div className="flex items-start justify-between gap-2 mb-3">
                    <div className="flex-1">
                      <p className="font-medium">{option.name}</p>
                      {parseFloat(option.price) > 0 && (
                        <Badge variant="secondary" className="mt-1">
                          +฿{parseFloat(option.price).toFixed(2)}
                        </Badge>
                      )}
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      className="flex-1"
                      onClick={() => handleEdit(option)}
                      data-testid={`button-edit-${option.id}`}
                    >
                      <Pencil className="w-3 h-3 mr-2" />
                      Edit
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => deleteMutation.mutate(option.id)}
                      disabled={deleteMutation.isPending}
                      data-testid={`button-delete-${option.id}`}
                    >
                      <Trash2 className="w-3 h-3" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    );
  };

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold">Options</h1>
          <p className="text-muted-foreground mt-2">Manage customization options</p>
        </div>
        <Skeleton className="h-96" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Options</h1>
        <p className="text-muted-foreground mt-2">Manage customization options</p>
      </div>

      <Tabs defaultValue="milk" className="space-y-6">
        <TabsList>
          <TabsTrigger value="milk" data-testid="tab-milk">Milk Types</TabsTrigger>
          <TabsTrigger value="sweetness" data-testid="tab-sweetness">Sweetness</TabsTrigger>
          <TabsTrigger value="addon" data-testid="tab-addon">Add-ons</TabsTrigger>
          <TabsTrigger value="extra" data-testid="tab-extra">Extras</TabsTrigger>
        </TabsList>

        <TabsContent value="milk">
          {renderOptionsList("milk", "Milk Types")}
        </TabsContent>

        <TabsContent value="sweetness">
          {renderOptionsList("sweetness", "Sweetness Levels")}
        </TabsContent>

        <TabsContent value="addon">
          {renderOptionsList("addon", "Add-ons")}
        </TabsContent>

        <TabsContent value="extra">
          {renderOptionsList("extra", "Extras")}
        </TabsContent>
      </Tabs>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>
              {editingOption ? "Edit Option" : "Add Option"}
            </DialogTitle>
            <DialogDescription>
              {editingOption ? "Update the option details" : "Create a new option"}
            </DialogDescription>
          </DialogHeader>

          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <FormField
                control={form.control}
                name="name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Name</FormLabel>
                    <FormControl>
                      <Input {...field} data-testid="input-option-name" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="price"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Additional Price</FormLabel>
                    <FormControl>
                      <Input {...field} type="number" step="0.01" data-testid="input-option-price" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <DialogFooter>
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => {
                    setDialogOpen(false);
                    setEditingOption(null);
                    form.reset();
                  }}
                  data-testid="button-cancel-option-dialog"
                >
                  Cancel
                </Button>
                <Button
                  type="submit"
                  disabled={createMutation.isPending || updateMutation.isPending}
                  data-testid="button-save-option"
                >
                  {createMutation.isPending || updateMutation.isPending
                    ? "Saving..."
                    : editingOption
                    ? "Update Option"
                    : "Create Option"}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
