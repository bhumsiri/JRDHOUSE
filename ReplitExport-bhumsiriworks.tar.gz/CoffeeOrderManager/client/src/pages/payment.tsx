import { useEffect, useState } from "react";
import { useLocation } from "wouter";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { CheckCircle2, Clock } from "lucide-react";
import promptPayQR from "@assets/IMG_6902_1762935875918.jpg";

export default function Payment() {
  const [, setLocation] = useLocation();
  const [orderNumber, setOrderNumber] = useState<number | null>(null);
  const [orderTotal, setOrderTotal] = useState<string | null>(null);

  useEffect(() => {
    const storedOrderNumber = sessionStorage.getItem("pendingOrderNumber");
    const storedOrderTotal = sessionStorage.getItem("pendingOrderTotal");
    
    if (!storedOrderNumber || !storedOrderTotal) {
      setLocation("/");
      return;
    }

    setOrderNumber(parseInt(storedOrderNumber));
    setOrderTotal(storedOrderTotal);
  }, [setLocation]);

  const handleDone = () => {
    setLocation("/waiting-confirmation");
  };

  if (!orderNumber || !orderTotal) {
    return null;
  }

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-background">
      <Card className="w-full max-w-2xl">
        <CardHeader className="text-center space-y-2">
          <div className="flex justify-center mb-2">
            <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center">
              <Clock className="w-8 h-8 text-primary" />
            </div>
          </div>
          <CardTitle className="text-3xl">Payment Required</CardTitle>
          <CardDescription className="text-base">
            Order #{orderNumber} - Please complete your payment
          </CardDescription>
          <Badge variant="secondary" className="text-xl px-4 py-2 w-fit mx-auto">
            ฿{parseFloat(orderTotal).toFixed(2)}
          </Badge>
        </CardHeader>

        <CardContent className="space-y-6">
          <div className="flex flex-col items-center space-y-4">
            <div className="bg-white p-4 rounded-lg shadow-md">
              <img 
                src={promptPayQR} 
                alt="PromptPay QR Code" 
                className="w-full max-w-sm h-auto"
                data-testid="img-promptpay-qr"
              />
            </div>

            <div className="text-center space-y-2 max-w-md">
              <h3 className="font-semibold text-lg">How to Pay</h3>
              <ol className="text-sm text-muted-foreground space-y-1 text-left">
                <li>1. Open your mobile banking app</li>
                <li>2. Scan the QR code above</li>
                <li>3. Confirm the amount: <span className="font-semibold">฿{parseFloat(orderTotal).toFixed(2)}</span></li>
                <li>4. Complete the payment</li>
                <li>5. Click "Done" below after payment</li>
              </ol>
            </div>

            <div className="bg-muted/50 p-4 rounded-lg text-center w-full">
              <p className="text-sm text-muted-foreground">
                <CheckCircle2 className="w-4 h-4 inline mr-1" />
                Your order will be confirmed after staff verification
              </p>
            </div>
          </div>

          <div className="flex flex-col gap-2 pt-4">
            <Button 
              size="lg" 
              className="w-full"
              onClick={handleDone}
              data-testid="button-payment-done"
            >
              I've Completed Payment
            </Button>
            <Button 
              variant="ghost" 
              size="sm"
              onClick={() => setLocation("/menu")}
              data-testid="button-back-to-menu"
            >
              Back to Menu
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
