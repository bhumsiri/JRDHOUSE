import { useEffect } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { CheckCircle, Coffee } from "lucide-react";

export default function OrderConfirmation() {
  const [, setLocation] = useLocation();
  const orderNumber = sessionStorage.getItem("lastOrderNumber");

  useEffect(() => {
    if (!orderNumber) {
      setLocation("/");
    }
  }, [orderNumber, setLocation]);

  const handleNewOrder = () => {
    sessionStorage.removeItem("lastOrderNumber");
    setLocation("/menu");
  };

  const handleDone = () => {
    sessionStorage.clear();
    setLocation("/");
  };

  if (!orderNumber) return null;

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-background">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center space-y-4">
          <div className="flex justify-center">
            <div className="w-20 h-20 rounded-full bg-primary/10 flex items-center justify-center">
              <CheckCircle className="w-12 h-12 text-primary" />
            </div>
          </div>
          <div className="space-y-2">
            <CardTitle className="text-3xl font-bold">Order Confirmed!</CardTitle>
            <CardDescription className="text-base">
              Your order has been successfully placed.
            </CardDescription>
          </div>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="bg-muted rounded-lg p-6 text-center space-y-2">
            <p className="text-sm text-muted-foreground font-medium">Order Number</p>
            <p className="text-4xl font-bold text-primary" data-testid="text-order-number">
              #{orderNumber}
            </p>
          </div>
          <p className="text-sm text-muted-foreground text-center">
            Please keep this number for reference. We'll have your order ready soon!
          </p>
          <div className="space-y-3">
            <Button
              className="w-full"
              size="lg"
              onClick={handleNewOrder}
              data-testid="button-new-order"
            >
              <Coffee className="w-4 h-4 mr-2" />
              Place Another Order
            </Button>
            <Button
              variant="outline"
              className="w-full"
              size="lg"
              onClick={handleDone}
              data-testid="button-done"
            >
              Done
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
