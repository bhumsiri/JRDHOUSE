import { useState, useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { ScrollArea, ScrollBar } from "@/components/ui/scroll-area";
import { Skeleton } from "@/components/ui/skeleton";
import { ShoppingCart, ArrowLeft, SearchX } from "lucide-react";
import type { Category, MenuItem, Option, OrderItem } from "@shared/schema";
import { ItemCustomizationDialog } from "@/components/item-customization-dialog";
import { CartDrawer } from "@/components/cart-drawer";
import potluckLogo from "@assets/image_1762934526423.png";

export default function Menu() {
  const [, setLocation] = useLocation();
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [selectedItem, setSelectedItem] = useState<MenuItem | null>(null);
  const [customizationOpen, setCustomizationOpen] = useState(false);
  const [cartOpen, setCartOpen] = useState(false);
  const [cart, setCart] = useState<OrderItem[]>([]);

  const customerName = sessionStorage.getItem("customerName");
  
  if (!customerName) {
    setLocation("/");
    return null;
  }

  const { data: categories, isLoading: categoriesLoading } = useQuery<Category[]>({
    queryKey: ["/api/categories"],
  });

  const { data: menuItems, isLoading: itemsLoading } = useQuery<MenuItem[]>({
    queryKey: ["/api/menu-items"],
  });

  const { data: options } = useQuery<Option[]>({
    queryKey: ["/api/options"],
  });

  const filteredItems = useMemo(() => {
    if (!menuItems) return [];
    if (!selectedCategory) return menuItems;
    return menuItems.filter(item => item.categoryId === selectedCategory);
  }, [menuItems, selectedCategory]);

  const cartItemsCount = cart.reduce((sum, item) => sum + item.quantity, 0);
  const cartTotal = cart.reduce((sum, item) => {
    const itemPrice = parseFloat(item.price);
    const optionsPrice = Object.values(item.selectedOptions || {}).flat().reduce((total, optionName) => {
      const option = options?.find(o => o.name === optionName);
      return total + (option ? parseFloat(option.price) : 0);
    }, 0);
    return sum + (itemPrice + optionsPrice) * item.quantity;
  }, 0);

  const handleAddToCart = (item: MenuItem) => {
    setSelectedItem(item);
    setCustomizationOpen(true);
  };

  const handleCustomizationSave = (orderItem: OrderItem) => {
    setCart([...cart, orderItem]);
    setCustomizationOpen(false);
    setSelectedItem(null);
  };

  const handleRemoveFromCart = (index: number) => {
    setCart(cart.filter((_, i) => i !== index));
  };

  const handleUpdateQuantity = (index: number, newQuantity: number) => {
    if (newQuantity <= 0) {
      handleRemoveFromCart(index);
      return;
    }
    const newCart = [...cart];
    newCart[index] = { ...newCart[index], quantity: newQuantity };
    setCart(newCart);
  };

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <header className="sticky top-0 z-30 bg-background border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setLocation("/")}
                data-testid="button-back"
              >
                <ArrowLeft className="w-5 h-5" />
              </Button>
              <img 
                src={potluckLogo} 
                alt="Potluck" 
                className="h-8 w-auto"
                data-testid="img-logo-menu"
              />
            </div>
            <div className="flex items-center gap-4">
              <div className="text-sm text-muted-foreground hidden sm:block">
                Welcome, <span className="font-medium text-foreground">{customerName}</span>
              </div>
              <Button
                variant="default"
                onClick={() => setCartOpen(true)}
                className="relative"
                data-testid="button-cart"
              >
                <ShoppingCart className="w-4 h-4 mr-2" />
                Cart
                {cartItemsCount > 0 && (
                  <Badge 
                    variant="secondary" 
                    className="ml-2 px-2 py-0 h-5 min-w-5 flex items-center justify-center"
                  >
                    {cartItemsCount}
                  </Badge>
                )}
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="sticky top-[73px] z-20 bg-background border-b">
        <div className="container mx-auto px-4 py-3">
          <ScrollArea className="w-full">
            <div className="flex gap-2">
              <Button
                variant={selectedCategory === null ? "default" : "outline"}
                size="sm"
                onClick={() => setSelectedCategory(null)}
                data-testid="button-category-all"
              >
                All
              </Button>
              {categoriesLoading ? (
                Array.from({ length: 4 }).map((_, i) => (
                  <Skeleton key={i} className="h-9 w-24" />
                ))
              ) : (
                categories?.map((category) => (
                  <Button
                    key={category.id}
                    variant={selectedCategory === category.id ? "default" : "outline"}
                    size="sm"
                    onClick={() => setSelectedCategory(category.id)}
                    data-testid={`button-category-${category.id}`}
                  >
                    {category.name}
                  </Button>
                ))
              )}
            </div>
            <ScrollBar orientation="horizontal" />
          </ScrollArea>
        </div>
      </div>

      <main className="flex-1 container mx-auto px-4 py-6">
        {itemsLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {Array.from({ length: 6 }).map((_, i) => (
              <Card key={i}>
                <Skeleton className="h-48 rounded-t-lg" />
                <CardHeader>
                  <Skeleton className="h-6 w-3/4" />
                  <Skeleton className="h-4 w-full" />
                  <Skeleton className="h-4 w-5/6" />
                </CardHeader>
                <CardFooter>
                  <Skeleton className="h-10 w-full" />
                </CardFooter>
              </Card>
            ))}
          </div>
        ) : filteredItems.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-16 text-center">
            <SearchX className="w-16 h-16 text-muted-foreground mb-4" />
            <h3 className="text-xl font-semibold mb-2">No items found</h3>
            <p className="text-muted-foreground">
              {selectedCategory 
                ? "This category doesn't have any items yet."
                : "No menu items available at the moment."}
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredItems.map((item) => (
              <Card key={item.id} className="flex flex-col overflow-hidden hover-elevate">
                {item.imageUrl && (
                  <div className="aspect-[4/3] bg-muted overflow-hidden">
                    <img 
                      src={item.imageUrl} 
                      alt={item.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                )}
                <CardHeader className="flex-1">
                  <div className="flex items-start justify-between gap-2">
                    <CardTitle className="text-xl">{item.name}</CardTitle>
                    <Badge variant="secondary" className="shrink-0">
                      ฿{parseFloat(item.price).toFixed(2)}
                    </Badge>
                  </div>
                  <CardDescription className="line-clamp-2">
                    {item.description}
                  </CardDescription>
                </CardHeader>
                <CardFooter>
                  <Button
                    className="w-full"
                    onClick={() => handleAddToCart(item)}
                    data-testid={`button-add-item-${item.id}`}
                  >
                    Add to Order
                  </Button>
                </CardFooter>
              </Card>
            ))}
          </div>
        )}
      </main>

      {selectedItem && (
        <ItemCustomizationDialog
          item={selectedItem}
          options={options || []}
          open={customizationOpen}
          onOpenChange={setCustomizationOpen}
          onSave={handleCustomizationSave}
        />
      )}

      <CartDrawer
        open={cartOpen}
        onOpenChange={setCartOpen}
        cart={cart}
        options={options || []}
        customerName={customerName}
        onRemoveItem={handleRemoveFromCart}
        onUpdateQuantity={handleUpdateQuantity}
        onClearCart={() => setCart([])}
      />
    </div>
  );
}
