import { useState } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import potluckLogo from "@assets/image_1762934526423.png";

export default function Welcome() {
  const [name, setName] = useState("");
  const [, setLocation] = useLocation();

  const handleStart = (e: React.FormEvent) => {
    e.preventDefault();
    if (name.trim()) {
      sessionStorage.setItem("customerName", name.trim());
      setLocation("/menu");
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-background">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center space-y-4">
          <div className="flex justify-center">
            <img 
              src={potluckLogo} 
              alt="Potluck" 
              className="h-16 w-auto"
              data-testid="img-logo"
            />
          </div>
          <div className="space-y-2">
            <CardDescription className="text-base">
              Welcome! Please enter your name to start ordering.
            </CardDescription>
          </div>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleStart} className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="name" className="text-base">Your Name</Label>
              <Input
                id="name"
                data-testid="input-customer-name"
                type="text"
                placeholder="Enter your name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="text-base"
                required
              />
            </div>
            <Button 
              type="submit" 
              className="w-full"
              size="lg"
              data-testid="button-start-ordering"
            >
              Start Ordering
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
