import { useState } from "react";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { Minus, Plus } from "lucide-react";
import type { MenuItem, Option, OrderItem } from "@shared/schema";

interface ItemCustomizationDialogProps {
  item: MenuItem;
  options: Option[];
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSave: (orderItem: OrderItem) => void;
}

export function ItemCustomizationDialog({
  item,
  options,
  open,
  onOpenChange,
  onSave,
}: ItemCustomizationDialogProps) {
  const [quantity, setQuantity] = useState(1);
  const [milkType, setMilkType] = useState<string>("");
  const [sweetness, setSweetness] = useState<string>("");
  const [addons, setAddons] = useState<string[]>([]);
  const [extras, setExtras] = useState<string[]>([]);
  const [notes, setNotes] = useState("");

  const milkOptions = options.filter(o => o.type === "milk");
  const sweetnessOptions = options.filter(o => o.type === "sweetness");
  const addonOptions = options.filter(o => o.type === "addon");
  const extraOptions = options.filter(o => o.type === "extra");

  const calculateTotal = () => {
    let total = parseFloat(item.price);
    
    const selectedOptionNames = [
      milkType,
      sweetness,
      ...addons,
      ...extras,
    ].filter(Boolean);

    selectedOptionNames.forEach(optionName => {
      const option = options.find(o => o.name === optionName);
      if (option) {
        total += parseFloat(option.price);
      }
    });

    return total * quantity;
  };

  const handleSave = () => {
    const orderItem: OrderItem = {
      id: item.id,
      name: item.name,
      price: item.price,
      quantity,
      selectedOptions: {
        milkType: milkType || undefined,
        sweetness: sweetness || undefined,
        addons: addons.length > 0 ? addons : undefined,
        extras: extras.length > 0 ? extras : undefined,
      },
      notes: notes.trim() || undefined,
    };

    onSave(orderItem);
    
    setQuantity(1);
    setMilkType("");
    setSweetness("");
    setAddons([]);
    setExtras([]);
    setNotes("");
  };

  const handleAddonToggle = (addonName: string) => {
    setAddons(prev => 
      prev.includes(addonName)
        ? prev.filter(a => a !== addonName)
        : [...prev, addonName]
    );
  };

  const handleExtraToggle = (extraName: string) => {
    setExtras(prev => 
      prev.includes(extraName)
        ? prev.filter(e => e !== extraName)
        : [...prev, extraName]
    );
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <div className="flex items-start justify-between gap-4">
            <div className="flex-1">
              <DialogTitle className="text-2xl">{item.name}</DialogTitle>
              <DialogDescription className="mt-2">
                {item.description}
              </DialogDescription>
            </div>
            <Badge variant="secondary" className="text-base px-3 py-1">
              ฿{parseFloat(item.price).toFixed(2)}
            </Badge>
          </div>
        </DialogHeader>

        <div className="space-y-6 mt-4">
          {milkOptions.length > 0 && (
            <div className="space-y-3">
              <Label className="text-base font-semibold">Milk Type</Label>
              <RadioGroup value={milkType} onValueChange={setMilkType}>
                <div className="grid grid-cols-2 gap-3">
                  {milkOptions.map((option) => (
                    <div key={option.id} className="flex items-center space-x-2">
                      <RadioGroupItem 
                        value={option.name} 
                        id={`milk-${option.id}`}
                        data-testid={`radio-milk-${option.name}`}
                      />
                      <Label 
                        htmlFor={`milk-${option.id}`} 
                        className="flex-1 cursor-pointer"
                      >
                        {option.name}
                        {parseFloat(option.price) > 0 && (
                          <span className="text-muted-foreground ml-1">
                            (+฿{parseFloat(option.price).toFixed(2)})
                          </span>
                        )}
                      </Label>
                    </div>
                  ))}
                </div>
              </RadioGroup>
            </div>
          )}

          {sweetnessOptions.length > 0 && (
            <div className="space-y-3">
              <Label className="text-base font-semibold">Sweetness Level</Label>
              <RadioGroup value={sweetness} onValueChange={setSweetness}>
                <div className="grid grid-cols-2 gap-3">
                  {sweetnessOptions.map((option) => (
                    <div key={option.id} className="flex items-center space-x-2">
                      <RadioGroupItem 
                        value={option.name} 
                        id={`sweet-${option.id}`}
                        data-testid={`radio-sweetness-${option.name}`}
                      />
                      <Label 
                        htmlFor={`sweet-${option.id}`} 
                        className="flex-1 cursor-pointer"
                      >
                        {option.name}
                      </Label>
                    </div>
                  ))}
                </div>
              </RadioGroup>
            </div>
          )}

          {addonOptions.length > 0 && (
            <div className="space-y-3">
              <Label className="text-base font-semibold">Add-ons</Label>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {addonOptions.map((option) => (
                  <div key={option.id} className="flex items-center space-x-2">
                    <Checkbox
                      id={`addon-${option.id}`}
                      checked={addons.includes(option.name)}
                      onCheckedChange={() => handleAddonToggle(option.name)}
                      data-testid={`checkbox-addon-${option.name}`}
                    />
                    <Label 
                      htmlFor={`addon-${option.id}`} 
                      className="flex-1 cursor-pointer"
                    >
                      {option.name}
                      {parseFloat(option.price) > 0 && (
                        <span className="text-muted-foreground ml-1">
                          (+฿{parseFloat(option.price).toFixed(2)})
                        </span>
                      )}
                    </Label>
                  </div>
                ))}
              </div>
            </div>
          )}

          {extraOptions.length > 0 && (
            <div className="space-y-3">
              <Label className="text-base font-semibold">Extras</Label>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {extraOptions.map((option) => (
                  <div key={option.id} className="flex items-center space-x-2">
                    <Checkbox
                      id={`extra-${option.id}`}
                      checked={extras.includes(option.name)}
                      onCheckedChange={() => handleExtraToggle(option.name)}
                      data-testid={`checkbox-extra-${option.name}`}
                    />
                    <Label 
                      htmlFor={`extra-${option.id}`} 
                      className="flex-1 cursor-pointer"
                    >
                      {option.name}
                      {parseFloat(option.price) > 0 && (
                        <span className="text-muted-foreground ml-1">
                          (+฿{parseFloat(option.price).toFixed(2)})
                        </span>
                      )}
                    </Label>
                  </div>
                ))}
              </div>
            </div>
          )}

          <div className="space-y-3">
            <Label htmlFor="notes" className="text-base font-semibold">
              Special Instructions
            </Label>
            <Textarea
              id="notes"
              data-testid="textarea-notes"
              placeholder="Any special requests? (optional)"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              className="resize-none h-24"
            />
          </div>

          <div className="space-y-3">
            <Label className="text-base font-semibold">Quantity</Label>
            <div className="flex items-center gap-3">
              <Button
                variant="outline"
                size="icon"
                onClick={() => setQuantity(Math.max(1, quantity - 1))}
                disabled={quantity <= 1}
                data-testid="button-decrease-quantity"
              >
                <Minus className="w-4 h-4" />
              </Button>
              <span className="text-xl font-semibold w-12 text-center" data-testid="text-quantity">
                {quantity}
              </span>
              <Button
                variant="outline"
                size="icon"
                onClick={() => setQuantity(quantity + 1)}
                data-testid="button-increase-quantity"
              >
                <Plus className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </div>

        <div className="flex items-center justify-between pt-6 border-t mt-6">
          <div>
            <p className="text-sm text-muted-foreground">Total</p>
            <p className="text-2xl font-bold" data-testid="text-total">
              ฿{calculateTotal().toFixed(2)}
            </p>
          </div>
          <Button
            size="lg"
            onClick={handleSave}
            data-testid="button-add-to-cart"
          >
            Add to Cart
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
