import { useState } from "react";
import { useLocation } from "wouter";
import { Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Minus, Plus, Trash2, ShoppingBag } from "lucide-react";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { OrderItem, Option } from "@shared/schema";

interface CartDrawerProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  cart: OrderItem[];
  options: Option[];
  customerName: string;
  onRemoveItem: (index: number) => void;
  onUpdateQuantity: (index: number, newQuantity: number) => void;
  onClearCart: () => void;
}

export function CartDrawer({
  open,
  onOpenChange,
  cart,
  options,
  customerName,
  onRemoveItem,
  onUpdateQuantity,
  onClearCart,
}: CartDrawerProps) {
  const [, setLocation] = useLocation();
  const { toast } = useToast();

  const placeOrderMutation = useMutation({
    mutationFn: async (orderData: any) => {
      const res = await apiRequest("POST", "/api/orders", orderData);
      return await res.json();
    },
    onSuccess: (data: any) => {
      sessionStorage.setItem("pendingOrderId", data.id);
      sessionStorage.setItem("pendingOrderNumber", data.orderNumber.toString());
      sessionStorage.setItem("pendingOrderTotal", data.total);
      onClearCart();
      onOpenChange(false);
      setLocation("/payment");
      toast({
        title: "Order created!",
        description: `Please complete payment for order #${data.orderNumber}`,
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to place order. Please try again.",
        variant: "destructive",
      });
    },
  });

  const calculateItemTotal = (item: OrderItem) => {
    const itemPrice = parseFloat(item.price);
    const optionsPrice = Object.values(item.selectedOptions || {}).flat().reduce((total, optionName) => {
      const option = options.find(o => o.name === optionName);
      return total + (option ? parseFloat(option.price) : 0);
    }, 0);
    return (itemPrice + optionsPrice) * item.quantity;
  };

  const cartTotal = cart.reduce((sum, item) => sum + calculateItemTotal(item), 0);

  const handlePlaceOrder = () => {
    const orderData = {
      customerName,
      items: cart,
      total: cartTotal.toFixed(2),
      orderNumber: Math.floor(Math.random() * 9000) + 1000,
      status: "new",
    };

    placeOrderMutation.mutate(orderData);
  };

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent className="w-full sm:max-w-lg flex flex-col">
        <SheetHeader>
          <SheetTitle className="text-2xl">Your Cart</SheetTitle>
          <SheetDescription>
            Review your order before checkout
          </SheetDescription>
        </SheetHeader>

        {cart.length === 0 ? (
          <div className="flex-1 flex flex-col items-center justify-center text-center py-12">
            <ShoppingBag className="w-16 h-16 text-muted-foreground mb-4" />
            <h3 className="text-xl font-semibold mb-2">Your cart is empty</h3>
            <p className="text-muted-foreground">
              Add some items from the menu to get started
            </p>
          </div>
        ) : (
          <>
            <ScrollArea className="flex-1 -mx-6 px-6">
              <div className="space-y-4 py-4">
                {cart.map((item, index) => {
                  const itemTotal = calculateItemTotal(item);
                  const selectedOptions = Object.entries(item.selectedOptions || {})
                    .filter(([, value]) => value && (Array.isArray(value) ? value.length > 0 : true))
                    .map(([key, value]) => ({
                      key,
                      value: Array.isArray(value) ? value : [value],
                    }));

                  return (
                    <div
                      key={index}
                      className="border rounded-lg p-4 space-y-3"
                      data-testid={`cart-item-${index}`}
                    >
                      <div className="flex items-start justify-between gap-3">
                        <div className="flex-1">
                          <h4 className="font-semibold">{item.name}</h4>
                          {selectedOptions.length > 0 && (
                            <div className="mt-2 space-y-1">
                              {selectedOptions.map(({ key, value }) => (
                                <p key={key} className="text-sm text-muted-foreground">
                                  {key === "milkType" && `Milk: ${value.join(", ")}`}
                                  {key === "sweetness" && `Sweetness: ${value.join(", ")}`}
                                  {key === "addons" && `Add-ons: ${value.join(", ")}`}
                                  {key === "extras" && `Extras: ${value.join(", ")}`}
                                </p>
                              ))}
                            </div>
                          )}
                          {item.notes && (
                            <p className="text-sm text-muted-foreground mt-2">
                              Note: {item.notes}
                            </p>
                          )}
                        </div>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => onRemoveItem(index)}
                          data-testid={`button-remove-${index}`}
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>

                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <Button
                            variant="outline"
                            size="icon"
                            className="h-8 w-8"
                            onClick={() => onUpdateQuantity(index, item.quantity - 1)}
                            data-testid={`button-decrease-${index}`}
                          >
                            <Minus className="w-3 h-3" />
                          </Button>
                          <span className="w-8 text-center font-medium" data-testid={`text-quantity-${index}`}>
                            {item.quantity}
                          </span>
                          <Button
                            variant="outline"
                            size="icon"
                            className="h-8 w-8"
                            onClick={() => onUpdateQuantity(index, item.quantity + 1)}
                            data-testid={`button-increase-${index}`}
                          >
                            <Plus className="w-3 h-3" />
                          </Button>
                        </div>
                        <Badge variant="secondary" className="text-base">
                          ฿{itemTotal.toFixed(2)}
                        </Badge>
                      </div>
                    </div>
                  );
                })}
              </div>
            </ScrollArea>

            <div className="space-y-4 pt-4 border-t">
              <div className="flex items-center justify-between text-lg">
                <span className="font-semibold">Total</span>
                <span className="text-2xl font-bold" data-testid="text-cart-total">
                  ฿{cartTotal.toFixed(2)}
                </span>
              </div>
              <Button
                className="w-full"
                size="lg"
                onClick={handlePlaceOrder}
                disabled={placeOrderMutation.isPending}
                data-testid="button-place-order"
              >
                {placeOrderMutation.isPending ? "Placing Order..." : "Place Order"}
              </Button>
            </div>
          </>
        )}
      </SheetContent>
    </Sheet>
  );
}
