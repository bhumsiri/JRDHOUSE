import { Switch, Route, useLocation } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider, useQuery } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { SidebarProvider, SidebarTrigger } from "@/components/ui/sidebar";
import { AdminSidebar } from "@/components/admin-sidebar";
import Welcome from "@/pages/welcome";
import Menu from "@/pages/menu";
import Payment from "@/pages/payment";
import WaitingConfirmation from "@/pages/waiting-confirmation";
import OrderTracking from "@/pages/order-tracking";
import OrderConfirmation from "@/pages/order-confirmation";
import AdminLogin from "@/pages/admin/login";
import AdminOrders from "@/pages/admin/orders";
import AdminMenu from "@/pages/admin/menu";
import AdminCategories from "@/pages/admin/categories";
import AdminOptions from "@/pages/admin/options";
import NotFound from "@/pages/not-found";
import { useEffect } from "react";

interface AuthCheckResponse {
  isAuthenticated: boolean;
  username?: string;
}

function AdminLayout({ children }: { children: React.ReactNode }) {
  const [, setLocation] = useLocation();
  const { data: authData, isLoading } = useQuery<AuthCheckResponse>({
    queryKey: ["/api/auth/check"],
  });

  useEffect(() => {
    if (!isLoading && !authData?.isAuthenticated) {
      setLocation("/admin/login");
    }
  }, [authData, isLoading, setLocation]);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-screen">
        <div className="text-muted-foreground">Loading...</div>
      </div>
    );
  }

  if (!authData?.isAuthenticated) {
    return null;
  }

  const style = {
    "--sidebar-width": "16rem",
    "--sidebar-width-icon": "3rem",
  };

  return (
    <SidebarProvider style={style as React.CSSProperties}>
      <div className="flex h-screen w-full">
        <AdminSidebar />
        <div className="flex flex-col flex-1">
          <header className="flex items-center justify-between p-4 border-b">
            <SidebarTrigger data-testid="button-sidebar-toggle" />
          </header>
          <main className="flex-1 overflow-auto">
            <div className="container mx-auto p-6">
              {children}
            </div>
          </main>
        </div>
      </div>
    </SidebarProvider>
  );
}

function Router() {
  return (
    <Switch>
      <Route path="/" component={Welcome} />
      <Route path="/menu" component={Menu} />
      <Route path="/payment" component={Payment} />
      <Route path="/waiting-confirmation" component={WaitingConfirmation} />
      <Route path="/order-tracking" component={OrderTracking} />
      <Route path="/order-confirmation" component={OrderConfirmation} />
      
      <Route path="/admin/login" component={AdminLogin} />
      
      <Route path="/admin/orders">
        <AdminLayout>
          <AdminOrders />
        </AdminLayout>
      </Route>
      <Route path="/admin">
        <AdminLayout>
          <AdminOrders />
        </AdminLayout>
      </Route>
      <Route path="/admin/menu">
        <AdminLayout>
          <AdminMenu />
        </AdminLayout>
      </Route>
      <Route path="/admin/categories">
        <AdminLayout>
          <AdminCategories />
        </AdminLayout>
      </Route>
      <Route path="/admin/options">
        <AdminLayout>
          <AdminOptions />
        </AdminLayout>
      </Route>
      
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
