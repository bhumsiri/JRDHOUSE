# Potluck - Coffee Ordering Platform

A responsive, lightweight dual-sided coffee ordering web application with Thai Baht (฿) currency and PromptPay payment integration. Features a customer-facing interface for browsing menu and placing orders, and a staff/admin interface for managing menu items, categories, options, viewing incoming orders, and confirming PromptPay payments.

## Project Overview

**Purpose**: Full-featured coffee shop ordering platform with PromptPay payment workflow  
**Tech Stack**: React + TypeScript, Express, WebSocket, Tailwind CSS, shadcn/ui  
**Architecture**: Full-stack JavaScript with in-memory storage, REST API, real-time updates  
**Currency**: Thai Baht (฿) throughout all interfaces  
**Status**: ✅ Production-ready with PromptPay payment integration and complete test coverage

## Recent Changes

**2025-11-12**: Production-ready session management with PostgreSQL
- Implemented PostgreSQL session storage using `connect-pg-simple` and standard `pg` driver
- Sessions now persist across server restarts and redeployments (production-ready)
- Configured production-safe cookie settings (sameSite, secure, httpOnly)
- Fixed login redirect issue - now successfully redirects to /admin/orders after login
- No MemoryStore warnings in production logs
- Supports horizontal scaling with multiple server instances

**2025-11-12**: Google Sheets transaction logging and branding
- Integrated Google Sheets API to automatically log all transactions
- Each order records: Order ID, Order Number, Customer Name, Items Summary, Total (฿), Timestamp
- Added "powered by JIRADA CO+OP" branding to order tracking page
- Transactions logged asynchronously with error handling

**2025-11-12**: Enhanced payment flow with waiting and tracking pages
- Created waiting confirmation page that polls order status every 2 seconds after customer marks payment complete
- Created order tracking page that displays order details, status, and payment confirmation
- Added public customer API endpoint (GET /api/customer/orders/:id) for customers to view orders without authentication
- Implemented automatic redirect from waiting page to order tracking after admin confirms payment
- Updated payment flow: payment → waiting → (admin confirms) → tracking
- Added support for "new" order status in tracking page
- End-to-end flow tested and verified successfully with architect approval

**2025-11-12**: Admin authentication system implemented
- Added secure session-based authentication for admin panel
- Created admin login page with username/password form
- Implemented login/logout API endpoints with bcrypt password hashing
- Protected all admin routes with authentication middleware
- Added logout button to admin sidebar
- Credentials: username "bhumsiri", password "134679"
- End-to-end authentication flow tested and verified successfully

**2025-11-12**: PromptPay payment integration completed
- Converted all currency symbols from $ to ฿ (Thai Baht) across customer and admin interfaces
- Created payment page displaying PromptPay QR code, order number, and total
- Implemented admin payment confirmation workflow with status tracking
- Added payment status badges ("Paid"/"Pending Payment") and confirmation timestamps
- Fixed routing to support /admin/orders path for admin dashboard
- End-to-end payment flow tested and verified successfully

**2025-11-12**: Final data-testid instrumentation completed
- Added data-testid attributes to all SelectItem elements in admin pages
- Achieved comprehensive test coverage across all interactive elements
- Received architect approval for production readiness

**2025-11-12**: Complete implementation
- Full customer ordering flow (welcome → menu → customization → cart → payment → waiting → tracking)
- Complete admin dashboard (orders, menu, categories, options management, payment confirmation)
- Real-time order updates via WebSocket
- Comprehensive data-testid instrumentation for automated testing

## User Preferences

### Coding Style
- Follow modern web application patterns and best practices
- Keep components minimal and collapse similar functionality into single files
- Use TypeScript for type safety across frontend and backend
- Follow design guidelines religiously for consistent UI/UX

### Design Philosophy
- Clean, minimal design following modern food ordering platform aesthetics
- Mobile-first responsive design
- Warm, inviting color palette appropriate for coffee shop branding
- Comprehensive use of shadcn/ui components for consistency

### Workflow
- In-memory storage (MemStorage) for data persistence
- Real-time updates via WebSocket for admin order notifications
- Comprehensive validation on both frontend and backend
- All interactive elements instrumented with data-testid for automated testing

## Project Architecture

### Frontend Structure

**Customer Pages** (`client/src/pages/`):
- `welcome.tsx`: Name entry before ordering
- `menu.tsx`: Browse menu with category filtering, add items to cart
- `payment.tsx`: Display PromptPay QR code, order number, and total after order placement
- `waiting-confirmation.tsx`: Poll order status while waiting for admin to confirm payment (2s interval)
- `order-tracking.tsx`: Display order details, status, and payment confirmation after admin confirms
- `order-confirmation.tsx`: Legacy confirmation page (deprecated in favor of tracking flow)

**Admin Pages** (`client/src/pages/admin/`):
- `login.tsx`: Secure login page for admin authentication
- `orders.tsx`: Real-time dashboard with WebSocket for incoming orders
- `menu.tsx`: CRUD operations for menu items with category selection
- `categories.tsx`: Manage menu categories
- `options.tsx`: Manage customization options (milk, sweetness, add-ons, extras)

**Key Components** (`client/src/components/`):
- `item-customization-dialog.tsx`: Modal for customizing menu items with all option types
- `cart-drawer.tsx`: Slide-out cart with quantity controls and order placement
- `admin-sidebar.tsx`: Navigation sidebar for admin interface

### Backend Structure

**Storage** (`server/storage.ts`):
- `IStorage` interface defining all CRUD operations
- `MemStorage` class implementing in-memory storage with seed data
- Manages categories, menu items, options, and orders

**API Routes** (`server/routes.ts`):
- Authentication endpoints (`/api/auth/login`, `/api/auth/logout`, `/api/auth/check`)
- Public customer endpoint (`/api/customer/orders/:id`) for viewing orders without authentication
- RESTful endpoints for all entities (protected with authentication middleware where appropriate)
- Request validation using Zod schemas
- WebSocket endpoint (`/ws`) for real-time order broadcasting

**Session Management** (`server/index.ts`):
- PostgreSQL session storage using `connect-pg-simple` with standard `pg` driver
- Sessions stored in database 'session' table (auto-created)
- Sessions persist across server restarts and scale horizontally
- Secure cookie configuration for production deployments (sameSite: 'none' with secure flag)
- HttpOnly cookies with 24-hour expiration
- SESSION_SECRET environment variable for production security

**Data Models** (`shared/schema.ts`):
- Complete TypeScript interfaces for all entities
- Zod schemas for validation
- Insert and select types for type safety

### Design System

**Colors & Typography**:
- Primary: Warm coffee brown (`#6B4423`)
- Accent: Cream/latte (`#E8D5C4`)
- Background: Warm off-white in light mode
- Font: Inter (clean, modern sans-serif)
- Defined in `client/src/index.css` and `tailwind.config.ts`

**Components**:
- Consistent use of shadcn/ui component library
- Elevation interactions via `hover-elevate` and `active-elevate-2` utilities
- Mobile-responsive layouts with proper spacing

## Key Features

### Customer Experience
1. **Name Entry**: Required before ordering (stored in localStorage)
2. **Menu Browsing**: Category-filtered menu with item cards showing descriptions and base prices in Thai Baht (฿)
3. **Item Customization**: 
   - Milk type selection (whole, skim, oat, almond, soy)
   - Sweetness level (0-4 with visual indicator)
   - Add-ons (flavor shots, extra espresso)
   - Extras (whipped cream, etc.)
   - Per-item notes
   - Quantity adjustment
4. **Cart Management**: Review items, adjust quantities, remove items with totals in ฿
5. **PromptPay Payment**: 
   - After order placement, redirected to payment page
   - Display PromptPay QR code for scanning
   - Shows order number and total amount in ฿
   - Payment instructions provided
6. **Waiting for Confirmation**:
   - After clicking "I've Completed Payment", customer sees waiting page
   - Page polls order status every 2 seconds
   - Displays pending confirmation message and order number
   - Automatically redirects to tracking when admin confirms payment
7. **Order Tracking**:
   - Displays complete order details after payment confirmation
   - Shows order number, items with customizations, total, and status
   - Payment confirmed indicator visible
   - Real-time status updates (new → pending → preparing → ready → completed)
   - Option to place another order or return to welcome

### Admin Experience
1. **Secure Authentication**:
   - Login page with username/password authentication
   - Session-based authentication with bcrypt password hashing
   - Protected admin routes requiring authentication
   - Logout functionality from admin sidebar
   - **Login Credentials**: Username: `bhumsiri`, Password: `134679`
2. **Real-Time Orders Dashboard**: 
   - WebSocket-powered live updates
   - Display customer name, items with customizations, total in ฿, timestamp
   - Order status badges (pending, preparing, ready, completed)
   - Payment status badges ("Paid" or "Pending Payment")
   - Confirm payment received button for pending payments
   - Display payment confirmation timestamp after confirmation
3. **Menu Management**: Create/edit/delete menu items with category assignment
4. **Category Management**: Organize menu structure
5. **Options Management**: Tabbed interface for managing all customization types

## Data Models

### Categories
```typescript
{ id: string, name: string, displayOrder: number }
```

### Menu Items
```typescript
{ 
  id: string, 
  name: string, 
  description: string, 
  price: number, 
  categoryId: string, 
  available: boolean 
}
```

### Options
```typescript
{
  id: string,
  name: string,
  type: 'milk' | 'sweetness' | 'addon' | 'extra',
  price: number
}
```

### Orders
```typescript
{
  id: string,
  orderNumber: number,
  customerName: string,
  items: OrderItem[],
  total: number,
  status: 'pending' | 'preparing' | 'ready' | 'completed',
  paymentStatus: 'pending' | 'confirmed',
  paymentConfirmedAt?: string,
  createdAt: string
}
```

## Testing Conventions

### Test Instrumentation
All user-facing interactive elements include `data-testid` attributes for automated testing:

**Naming Convention**:
- Interactive elements: `{action}-{target}` (e.g., `button-submit`, `input-email`)
- Display elements: `{type}-{content}` (e.g., `text-username`, `text-price`)
- Dynamic elements: `{type}-{description}-{id}` (e.g., `card-item-${itemId}`)

**Coverage**:
- ✅ All buttons, inputs, textareas
- ✅ Select triggers and select items
- ✅ Cart controls and order actions
- ✅ Admin CRUD operations
- ✅ Navigation elements

**Example**:
```tsx
<Button data-testid="button-place-order" onClick={handleOrder}>
  Place Order
</Button>
```

## Running the Application

**Development**:
```bash
npm run dev
```
Starts Express backend and Vite frontend on the same port (binds to 0.0.0.0:5000).

**Access Points**:
- Customer Interface: `/` (root)
- Customer Payment Flow: `/payment` → `/waiting-confirmation` → `/order-tracking`
- Admin Login: `/admin/login`
- Admin Interface: `/admin/orders` (requires authentication)

**WebSocket**: 
- Endpoint: `/ws`
- Purpose: Real-time order notifications to admin dashboard

## Environment Variables

- `SESSION_SECRET`: Session management (already configured)
- `NODE_ENV`: Environment mode (development/production)
- `GOOGLE_SHEET_ID`: Google Sheet spreadsheet ID for transaction logging (optional - if not set, transactions won't be logged)

## Dependencies

**Key Libraries**:
- React 18 with TypeScript
- Wouter for client-side routing
- TanStack Query for data fetching
- Zod for validation
- Drizzle ORM for schema definitions
- shadcn/ui component library
- Lucide React for icons
- WebSocket (ws) for real-time updates

## Project State

**Completed**:
- ✅ Complete data schema and TypeScript types
- ✅ Full customer ordering experience with enhanced payment flow
- ✅ Complete admin management interface with secure authentication
- ✅ Backend API with validation and authentication middleware
- ✅ Public customer API endpoint for order viewing
- ✅ Real-time order updates via WebSocket
- ✅ Responsive design with mobile support
- ✅ Comprehensive test instrumentation
- ✅ PromptPay payment integration with admin confirmation
- ✅ Waiting page with polling for payment confirmation
- ✅ Order tracking page with status updates
- ✅ Thai Baht (฿) currency throughout all interfaces
- ✅ Secure admin authentication with login/logout functionality
- ✅ End-to-end payment, waiting, tracking, and authentication flows tested and verified

**Ready For**:
- Deployment/publishing
- Automated test suite development
- Additional features (customer accounts, order history, inventory management, etc.)

## Notes

- In-memory storage means data resets on server restart (suitable for development)
- For production, consider migrating to PostgreSQL using Drizzle ORM migrations
- WebSocket connection handles real-time order updates to admin dashboard
- Design follows modern food ordering platform patterns with warm coffee shop aesthetics
