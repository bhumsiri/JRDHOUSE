# Potluck Coffee Ordering - Design Guidelines

## Design Approach

**Selected Approach:** Reference-Based (Food/Beverage Commerce)

Drawing inspiration from modern food ordering platforms (Square, Toast) combined with clean admin interfaces (Linear, Notion) to create a lightweight, efficient dual-sided application.

**Core Principles:**
- Clean, minimal aesthetic prioritizing speed and clarity
- Visual appetite appeal for customer side
- Functional efficiency for admin side
- Consistent branding across both interfaces

---

## Typography System

**Font Stack:**
- Primary: Inter (via Google Fonts CDN)
- Fallback: system-ui, sans-serif

**Hierarchy:**
- Display (Brand/Hero): text-4xl md:text-5xl, font-bold
- Section Headers: text-2xl md:text-3xl, font-semibold
- Card Titles: text-lg md:text-xl, font-semibold
- Body Text: text-base, font-normal
- Captions/Labels: text-sm, font-medium
- Small Print: text-xs, font-normal

---

## Layout System

**Spacing Primitives:** Use Tailwind units of 2, 4, 6, 8, 12, 16 for consistent rhythm
- Tight spacing: p-2, gap-2 (form elements, buttons)
- Standard spacing: p-4, gap-4 (cards, sections)
- Generous spacing: p-6, p-8 (containers, sections)
- Large spacing: py-12, py-16 (page sections)

**Container Strategy:**
- Max width: max-w-7xl for main content areas
- Admin panels: max-w-6xl
- Forms: max-w-2xl
- Mobile-first responsive breakpoints: sm, md, lg, xl

**Grid Systems:**
- Menu items: grid-cols-1 md:grid-cols-2 lg:grid-cols-3
- Admin tables: Single column on mobile, full table on desktop
- Category cards: grid-cols-2 md:grid-cols-3 lg:grid-cols-4

---

## Customer-Facing Interface

### Welcome Screen
- Clean centered layout with Potluck branding
- Name input form (centered, max-w-md)
- Minimal welcome message above input
- Single prominent "Start Ordering" button below

### Menu Browse
**Layout:** Category-organized browsing with visual hierarchy

**Menu Item Cards:**
- Square or 4:3 ratio product images at top
- Item name, description (2 lines max), price clearly displayed
- "Add to Order" button at bottom
- Hover state: subtle lift effect (transform scale)
- Grid layout with consistent gaps (gap-4 md:gap-6)

**Category Navigation:**
- Horizontal scrolling category pills at top (sticky on scroll)
- Active category highlighted
- Icons from Heroicons for visual markers

### Customization Modal/Drawer
**Structure:**
- Product image thumbnail at top
- Organized sections for each option type:
  - Milk Type (radio buttons in grid)
  - Sweetness Level (radio buttons or slider)
  - Add-ons (checkboxes in grid)
  - Extras (checkboxes in grid)
- Special instructions textarea (h-24, border)
- Quantity selector with +/- buttons
- Price calculator showing total
- "Add to Cart" button (fixed at bottom on mobile)

### Cart & Checkout
- Slide-out drawer from right on desktop
- Full-screen on mobile
- Line items with edit/remove options
- Order summary with subtotal, tax (if applicable), total
- Customer name reminder at top
- "Place Order" prominent button
- Order confirmation screen with order number (large, centered)

---

## Admin/Staff Interface

### Dashboard Layout
**Navigation:**
- Left sidebar on desktop (w-64)
- Collapsible hamburger menu on mobile
- Sections: Orders, Menu Items, Categories, Options
- Potluck logo at top

### Order Management
- Real-time order list (card-based on mobile, table on desktop)
- Order cards showing:
  - Order number, customer name, timestamp
  - Full item list with all customizations
  - Special notes highlighted
  - Status indicator (New/In Progress/Complete)
- Expandable rows for order details

### Menu Management
**Item Editor:**
- Form-based layout with clear sections
- Image upload placeholder
- Text inputs for name, description, price
- Category dropdown selector
- Save/Cancel buttons (sticky footer on mobile)

**Item List:**
- Grid of existing items with edit/delete actions
- Quick search/filter by category
- "Add New Item" button (prominent, top-right)

### Category Management
- Simple list with add/edit/delete
- Drag-and-drop reordering indicators (use <!-- CUSTOM ICON: drag handle -->)
- Inline editing for quick updates

### Options Management
**Organized Tabs:**
- Milk Types, Sweetness Levels, Add-ons, Extras
- Each tab contains list of options
- Add/edit/delete for each type
- Price modifier input (for add-ons/extras)

---

## Component Library

**Buttons:**
- Primary: Solid, rounded-lg, py-3 px-6, font-medium
- Secondary: Outlined, rounded-lg, py-3 px-6
- Icon buttons: Rounded-full, p-2

**Form Inputs:**
- Text inputs: border, rounded-md, px-4 py-2
- Textareas: border, rounded-md, p-4
- Radio/Checkbox: Custom styled with Heroicons check icons
- Dropdowns: border, rounded-md, px-4 py-2

**Cards:**
- Rounded-lg, border or subtle shadow
- Padding: p-4 md:p-6
- Hover states for interactive cards

**Modals/Drawers:**
- Backdrop overlay with blur
- Slide-in animation from right (drawers)
- Fade-in for modals
- Close button (top-right)

**Navigation:**
- Mobile: Bottom tab bar or hamburger menu
- Desktop: Top navigation or sidebar
- Active states clearly indicated

---

## Images

**Product Images:**
- Menu items require appetizing coffee/beverage photography
- Square format (1:1) or 4:3 ratio for consistency
- High-quality, well-lit product shots
- Consistent background treatment (white or subtle neutral)
- Size: Minimum 400x400px for clarity

**Image Placement:**
- Menu item cards: Top of each card, full-width
- Customization modal: Small thumbnail (80x80px) for context
- Admin item editor: Upload preview (200x200px)

**No Hero Image:** This is a functional ordering app - skip traditional hero sections in favor of immediate functionality.

---

## Responsive Behavior

**Breakpoints:**
- Mobile-first approach
- sm (640px): 2-column grids where appropriate
- md (768px): Full navigation, expanded layouts
- lg (1024px): 3-column grids, optimal desktop layout

**Mobile Optimizations:**
- Full-screen modals for customization
- Bottom sheet for cart
- Larger touch targets (min 44x44px)
- Simplified navigation

**Desktop Enhancements:**
- Sidebar navigation (admin)
- Multi-column layouts
- Hover states and tooltips
- Keyboard shortcuts (admin)