import type { Express, Request, Response, NextFunction } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from "ws";
import bcrypt from "bcryptjs";
import { storage } from "./storage";
import { 
  insertCategorySchema, 
  insertMenuItemSchema, 
  insertOptionSchema, 
  insertOrderSchema,
  type Order 
} from "@shared/schema";
import { logTransactionToSheet } from "./googleSheets";

// DEVELOPMENT ONLY: Hardcoded credentials for demo purposes
// For production, use environment variables and a proper user management system
const ADMIN_USERNAME = "bhumsiri";
const ADMIN_PASSWORD_HASH = bcrypt.hashSync("134679", 10);

function requireAuth(req: Request, res: Response, next: NextFunction) {
  if (req.session.isAuthenticated) {
    return next();
  }
  return res.status(401).json({ error: "Unauthorized" });
}

export async function registerRoutes(app: Express): Promise<Server> {
  const httpServer = createServer(app);
  
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });
  const clients = new Set<WebSocket>();

  wss.on('connection', (ws) => {
    clients.add(ws);
    console.log('WebSocket client connected');

    ws.on('close', () => {
      clients.delete(ws);
      console.log('WebSocket client disconnected');
    });
  });

  function broadcastNewOrder(order: any) {
    const message = JSON.stringify({ type: 'NEW_ORDER', order });
    clients.forEach((client) => {
      if (client.readyState === WebSocket.OPEN) {
        client.send(message);
      }
    });
  }

  app.post("/api/auth/login", async (req, res) => {
    const { username, password } = req.body;

    if (!username || !password) {
      return res.status(400).json({ error: "Username and password are required" });
    }

    if (username === ADMIN_USERNAME && bcrypt.compareSync(password, ADMIN_PASSWORD_HASH)) {
      req.session.isAuthenticated = true;
      req.session.username = username;
      
      // Explicitly save session before sending response
      req.session.save((err) => {
        if (err) {
          console.error('Session save error:', err);
          return res.status(500).json({ error: "Failed to save session" });
        }
        return res.json({ success: true, username });
      });
    } else {
      return res.status(401).json({ error: "Invalid credentials" });
    }
  });

  app.post("/api/auth/logout", (req, res) => {
    req.session.destroy((err) => {
      if (err) {
        return res.status(500).json({ error: "Failed to logout" });
      }
      res.clearCookie('connect.sid');
      res.json({ success: true });
    });
  });

  app.get("/api/auth/check", (req, res) => {
    if (req.session.isAuthenticated) {
      return res.json({ isAuthenticated: true, username: req.session.username });
    }
    return res.json({ isAuthenticated: false });
  });

  app.get("/api/categories", async (req, res) => {
    const categories = await storage.getCategories();
    res.json(categories);
  });

  app.get("/api/categories/:id", async (req, res) => {
    const category = await storage.getCategory(req.params.id);
    if (!category) {
      return res.status(404).json({ error: "Category not found" });
    }
    res.json(category);
  });

  app.post("/api/categories", requireAuth, async (req, res) => {
    try {
      const data = insertCategorySchema.parse(req.body);
      const category = await storage.createCategory(data);
      res.status(201).json(category);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  app.patch("/api/categories/:id", requireAuth, async (req, res) => {
    try {
      const data = insertCategorySchema.partial().parse(req.body);
      const category = await storage.updateCategory(req.params.id, data);
      if (!category) {
        return res.status(404).json({ error: "Category not found" });
      }
      res.json(category);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  app.delete("/api/categories/:id", requireAuth, async (req, res) => {
    const deleted = await storage.deleteCategory(req.params.id);
    if (!deleted) {
      return res.status(404).json({ error: "Category not found" });
    }
    res.status(204).send();
  });

  app.get("/api/menu-items", async (req, res) => {
    const items = await storage.getMenuItems();
    res.json(items);
  });

  app.get("/api/menu-items/:id", async (req, res) => {
    const item = await storage.getMenuItem(req.params.id);
    if (!item) {
      return res.status(404).json({ error: "Menu item not found" });
    }
    res.json(item);
  });

  app.post("/api/menu-items", requireAuth, async (req, res) => {
    try {
      const data = insertMenuItemSchema.parse(req.body);
      const item = await storage.createMenuItem(data);
      res.status(201).json(item);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  app.patch("/api/menu-items/:id", requireAuth, async (req, res) => {
    try {
      const data = insertMenuItemSchema.partial().parse(req.body);
      const item = await storage.updateMenuItem(req.params.id, data);
      if (!item) {
        return res.status(404).json({ error: "Menu item not found" });
      }
      res.json(item);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  app.delete("/api/menu-items/:id", requireAuth, async (req, res) => {
    const deleted = await storage.deleteMenuItem(req.params.id);
    if (!deleted) {
      return res.status(404).json({ error: "Menu item not found" });
    }
    res.status(204).send();
  });

  app.get("/api/options", async (req, res) => {
    const options = await storage.getOptions();
    res.json(options);
  });

  app.get("/api/options/:id", async (req, res) => {
    const option = await storage.getOption(req.params.id);
    if (!option) {
      return res.status(404).json({ error: "Option not found" });
    }
    res.json(option);
  });

  app.post("/api/options", requireAuth, async (req, res) => {
    try {
      const data = insertOptionSchema.parse(req.body);
      const option = await storage.createOption(data);
      res.status(201).json(option);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  app.patch("/api/options/:id", requireAuth, async (req, res) => {
    try {
      const data = insertOptionSchema.partial().parse(req.body);
      const option = await storage.updateOption(req.params.id, data);
      if (!option) {
        return res.status(404).json({ error: "Option not found" });
      }
      res.json(option);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  app.delete("/api/options/:id", requireAuth, async (req, res) => {
    const deleted = await storage.deleteOption(req.params.id);
    if (!deleted) {
      return res.status(404).json({ error: "Option not found" });
    }
    res.status(204).send();
  });

  app.get("/api/orders", requireAuth, async (req, res) => {
    const orders = await storage.getOrders();
    res.json(orders);
  });

  app.get("/api/orders/:id", requireAuth, async (req, res) => {
    const order = await storage.getOrder(req.params.id);
    if (!order) {
      return res.status(404).json({ error: "Order not found" });
    }
    res.json(order);
  });

  // Public endpoint for customers to view their orders
  app.get("/api/customer/orders/:id", async (req, res) => {
    const order = await storage.getOrder(req.params.id);
    if (!order) {
      return res.status(404).json({ error: "Order not found" });
    }
    res.json(order);
  });

  app.post("/api/orders", async (req, res) => {
    try {
      const data = insertOrderSchema.parse(req.body);
      const order: Order = await storage.createOrder(data);
      
      broadcastNewOrder(order);
      
      // Log transaction to Google Sheets
      const itemsSummary = order.items.map((item: any) => 
        `${item.quantity}x ${item.name}`
      ).join(', ');
      
      logTransactionToSheet({
        orderId: order.id,
        orderNumber: order.orderNumber,
        customerName: order.customerName,
        items: itemsSummary,
        total: `฿${order.total}`,
        timestamp: new Date(order.createdAt).toISOString()
      }).catch(err => console.error('Failed to log transaction:', err));
      
      res.status(201).json(order);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  app.patch("/api/orders/:id", requireAuth, async (req, res) => {
    try {
      const data = insertOrderSchema.partial().parse(req.body);
      const order = await storage.updateOrder(req.params.id, data);
      if (!order) {
        return res.status(404).json({ error: "Order not found" });
      }
      res.json(order);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  app.delete("/api/orders/:id", requireAuth, async (req, res) => {
    const deleted = await storage.deleteOrder(req.params.id);
    if (!deleted) {
      return res.status(404).json({ error: "Order not found" });
    }
    res.status(204).send();
  });

  app.post("/api/orders/:id/confirm-payment", requireAuth, async (req, res) => {
    try {
      const order = await storage.confirmPayment(req.params.id);
      if (!order) {
        return res.status(404).json({ error: "Order not found" });
      }
      res.json(order);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  return httpServer;
}
