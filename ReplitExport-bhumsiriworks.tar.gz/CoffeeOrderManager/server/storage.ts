import { 
  type Category, 
  type InsertCategory,
  type MenuItem,
  type InsertMenuItem,
  type Option,
  type InsertOption,
  type Order,
  type InsertOrder,
} from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  getCategories(): Promise<Category[]>;
  getCategory(id: string): Promise<Category | undefined>;
  createCategory(category: InsertCategory): Promise<Category>;
  updateCategory(id: string, category: Partial<InsertCategory>): Promise<Category | undefined>;
  deleteCategory(id: string): Promise<boolean>;

  getMenuItems(): Promise<MenuItem[]>;
  getMenuItem(id: string): Promise<MenuItem | undefined>;
  createMenuItem(item: InsertMenuItem): Promise<MenuItem>;
  updateMenuItem(id: string, item: Partial<InsertMenuItem>): Promise<MenuItem | undefined>;
  deleteMenuItem(id: string): Promise<boolean>;

  getOptions(): Promise<Option[]>;
  getOption(id: string): Promise<Option | undefined>;
  createOption(option: InsertOption): Promise<Option>;
  updateOption(id: string, option: Partial<InsertOption>): Promise<Option | undefined>;
  deleteOption(id: string): Promise<boolean>;

  getOrders(): Promise<Order[]>;
  getOrder(id: string): Promise<Order | undefined>;
  createOrder(order: InsertOrder): Promise<Order>;
  updateOrder(id: string, order: Partial<InsertOrder>): Promise<Order | undefined>;
  deleteOrder(id: string): Promise<boolean>;
  confirmPayment(id: string): Promise<Order | undefined>;
}

export class MemStorage implements IStorage {
  private categories: Map<string, Category>;
  private menuItems: Map<string, MenuItem>;
  private options: Map<string, Option>;
  private orders: Map<string, Order>;

  constructor() {
    this.categories = new Map();
    this.menuItems = new Map();
    this.options = new Map();
    this.orders = new Map();
    
    this.seedInitialData();
  }

  private seedInitialData() {
    const category1: Category = {
      id: randomUUID(),
      name: "Coffee",
      order: 0,
    };
    const category2: Category = {
      id: randomUUID(),
      name: "Tea",
      order: 1,
    };
    const category3: Category = {
      id: randomUUID(),
      name: "Specialty Drinks",
      order: 2,
    };

    this.categories.set(category1.id, category1);
    this.categories.set(category2.id, category2);
    this.categories.set(category3.id, category3);

    const menuItem1: MenuItem = {
      id: randomUUID(),
      name: "Espresso",
      description: "Rich and bold single shot of espresso",
      price: "3.50",
      categoryId: category1.id,
      imageUrl: null,
    };
    const menuItem2: MenuItem = {
      id: randomUUID(),
      name: "Cappuccino",
      description: "Espresso with steamed milk and foam",
      price: "4.50",
      categoryId: category1.id,
      imageUrl: null,
    };
    const menuItem3: MenuItem = {
      id: randomUUID(),
      name: "Latte",
      description: "Smooth espresso with steamed milk",
      price: "4.75",
      categoryId: category1.id,
      imageUrl: null,
    };

    this.menuItems.set(menuItem1.id, menuItem1);
    this.menuItems.set(menuItem2.id, menuItem2);
    this.menuItems.set(menuItem3.id, menuItem3);

    const milkOptions = [
      { name: "Whole Milk", price: "0" },
      { name: "Skim Milk", price: "0" },
      { name: "Oat Milk", price: "0.75" },
      { name: "Almond Milk", price: "0.75" },
      { name: "Soy Milk", price: "0.50" },
    ];
    
    milkOptions.forEach(opt => {
      const option: Option = {
        id: randomUUID(),
        type: "milk",
        name: opt.name,
        price: opt.price,
      };
      this.options.set(option.id, option);
    });

    const sweetnessOptions = [
      { name: "No Sugar", price: "0" },
      { name: "Light", price: "0" },
      { name: "Regular", price: "0" },
      { name: "Extra Sweet", price: "0" },
    ];
    
    sweetnessOptions.forEach(opt => {
      const option: Option = {
        id: randomUUID(),
        type: "sweetness",
        name: opt.name,
        price: opt.price,
      };
      this.options.set(option.id, option);
    });

    const addonOptions = [
      { name: "Extra Shot", price: "1.50" },
      { name: "Vanilla Syrup", price: "0.75" },
      { name: "Caramel Syrup", price: "0.75" },
      { name: "Hazelnut Syrup", price: "0.75" },
    ];
    
    addonOptions.forEach(opt => {
      const option: Option = {
        id: randomUUID(),
        type: "addon",
        name: opt.name,
        price: opt.price,
      };
      this.options.set(option.id, option);
    });

    const extraOptions = [
      { name: "Whipped Cream", price: "0.50" },
      { name: "Chocolate Drizzle", price: "0.50" },
      { name: "Cinnamon", price: "0" },
    ];
    
    extraOptions.forEach(opt => {
      const option: Option = {
        id: randomUUID(),
        type: "extra",
        name: opt.name,
        price: opt.price,
      };
      this.options.set(option.id, option);
    });
  }

  async getCategories(): Promise<Category[]> {
    return Array.from(this.categories.values());
  }

  async getCategory(id: string): Promise<Category | undefined> {
    return this.categories.get(id);
  }

  async createCategory(insertCategory: InsertCategory): Promise<Category> {
    const id = randomUUID();
    const category: Category = { ...insertCategory, id };
    this.categories.set(id, category);
    return category;
  }

  async updateCategory(id: string, update: Partial<InsertCategory>): Promise<Category | undefined> {
    const category = this.categories.get(id);
    if (!category) return undefined;
    
    const updated = { ...category, ...update };
    this.categories.set(id, updated);
    return updated;
  }

  async deleteCategory(id: string): Promise<boolean> {
    return this.categories.delete(id);
  }

  async getMenuItems(): Promise<MenuItem[]> {
    return Array.from(this.menuItems.values());
  }

  async getMenuItem(id: string): Promise<MenuItem | undefined> {
    return this.menuItems.get(id);
  }

  async createMenuItem(insertItem: InsertMenuItem): Promise<MenuItem> {
    const id = randomUUID();
    const item: MenuItem = { ...insertItem, id };
    this.menuItems.set(id, item);
    return item;
  }

  async updateMenuItem(id: string, update: Partial<InsertMenuItem>): Promise<MenuItem | undefined> {
    const item = this.menuItems.get(id);
    if (!item) return undefined;
    
    const updated = { ...item, ...update };
    this.menuItems.set(id, updated);
    return updated;
  }

  async deleteMenuItem(id: string): Promise<boolean> {
    return this.menuItems.delete(id);
  }

  async getOptions(): Promise<Option[]> {
    return Array.from(this.options.values());
  }

  async getOption(id: string): Promise<Option | undefined> {
    return this.options.get(id);
  }

  async createOption(insertOption: InsertOption): Promise<Option> {
    const id = randomUUID();
    const option: Option = { ...insertOption, id };
    this.options.set(id, option);
    return option;
  }

  async updateOption(id: string, update: Partial<InsertOption>): Promise<Option | undefined> {
    const option = this.options.get(id);
    if (!option) return undefined;
    
    const updated = { ...option, ...update };
    this.options.set(id, updated);
    return updated;
  }

  async deleteOption(id: string): Promise<boolean> {
    return this.options.delete(id);
  }

  async getOrders(): Promise<Order[]> {
    return Array.from(this.orders.values());
  }

  async getOrder(id: string): Promise<Order | undefined> {
    return this.orders.get(id);
  }

  async createOrder(insertOrder: InsertOrder): Promise<Order> {
    const id = randomUUID();
    const order: Order = {
      ...insertOrder,
      id,
      items: insertOrder.items as any,
      paymentStatus: "pending",
      paymentConfirmedAt: null,
      createdAt: new Date(),
    };
    this.orders.set(id, order);
    return order;
  }

  async updateOrder(id: string, update: Partial<InsertOrder>): Promise<Order | undefined> {
    const order = this.orders.get(id);
    if (!order) return undefined;
    
    const updated = { ...order, ...update, items: (update.items || order.items) as any };
    this.orders.set(id, updated);
    return updated;
  }

  async deleteOrder(id: string): Promise<boolean> {
    return this.orders.delete(id);
  }

  async confirmPayment(id: string): Promise<Order | undefined> {
    const order = this.orders.get(id);
    if (!order) return undefined;
    
    const updated = { 
      ...order, 
      paymentStatus: "confirmed",
      paymentConfirmedAt: new Date()
    };
    this.orders.set(id, updated);
    return updated;
  }
}

export const storage = new MemStorage();
